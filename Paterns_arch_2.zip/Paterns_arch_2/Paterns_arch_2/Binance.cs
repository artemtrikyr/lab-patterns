﻿using System;
using System.Collections.Generic;
using System.Linq;


//Конкретні біржи

namespace Paterns_arch_2
{
    public class Binance : ICryptoExchange
    {
        private readonly List<decimal> priceHistory = new List<decimal> { 26500, 72000, 38500, 94000, 51000, 68500, 33000, 57000, 76000, 45500, 91000, 29500, 82000, 36000, 63000, 98000, 41500, 88000, 27500, 65000
 };

        public List<decimal> GetPriceHistory() => priceHistory;

        //Рандомом вибирається поточна ціна
        public decimal GetCurrentPrice()
        {
            Random rnd = new Random();
            // до одної із цін (ціна береться із списку історій цін) додається число в діапазоні від -500 до 500
            return priceHistory[rnd.Next(priceHistory.Count)] + rnd.Next(-500, 500);
            
        }
    }

    public class Coinbase : ICryptoExchange
    {
        private readonly List<decimal> priceHistory = new List<decimal> { 38000, 39000, 37000, 40000, 41000, 45000, 47000, 32000, 52000, 60000, 29000, 54000, 75000, 80000, 66000, 88000, 30000, 90000, 63000, 99000 };

        public List<decimal> GetPriceHistory() => priceHistory;

        public decimal GetCurrentPrice()
        {
            Random rnd = new Random();
            return priceHistory[rnd.Next(priceHistory.Count)] + rnd.Next(-500, 500);  
        }
    }
}

