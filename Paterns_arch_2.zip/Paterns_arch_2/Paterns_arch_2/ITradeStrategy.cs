﻿using System;
using System.Collections.Generic;
using System.Linq;

// Інтерфейс стратегії
namespace Paterns_arch_2
{
    public interface ITradeStrategy
    {
        decimal GetBuyPrice(List<decimal> priceHistory);
        decimal GetSellPrice(List<decimal> priceHistory);
    }
}

