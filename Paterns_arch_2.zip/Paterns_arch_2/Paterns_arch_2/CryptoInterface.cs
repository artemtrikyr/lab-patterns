﻿using System;
using System.Collections.Generic;
using System.Linq;

//Інтерфейси для отримання історії цін із біржи та ціну на даний момент
namespace Paterns_arch_2
{
    public interface ICryptoExchange
    {
        List<decimal> GetPriceHistory();  
        decimal GetCurrentPrice();
    }
}

