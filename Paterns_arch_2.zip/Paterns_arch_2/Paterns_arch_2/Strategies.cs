﻿using System;
using System.Collections.Generic;
using System.Linq;

//Безпосередньо самі стратегії 
namespace Paterns_arch_2
{
    public class GreedyStrategy : ITradeStrategy
    {
        public decimal GetBuyPrice(List<decimal> priceHistory) => priceHistory.Min();
        public decimal GetSellPrice(List<decimal> priceHistory) => priceHistory.Max();
    }

    public class AveragePriceStrategy : ITradeStrategy
    {
        public decimal GetBuyPrice(List<decimal> priceHistory) => priceHistory.Average();
        public decimal GetSellPrice(List<decimal> priceHistory) => priceHistory.Average();
    }
}

