﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Paterns_arch_2
{
    public class Program
    {
        static void Main(string[] args)
        {
            // Ініціалізуємо стратегії
            ITradeStrategy greedyStrategy = new GreedyStrategy();
            ITradeStrategy averagePriceStrategy = new AveragePriceStrategy();

            // Ініціалізуємо біржі
            ICryptoExchange binance = new Binance();
            ICryptoExchange coinbase = new Coinbase();

            // Binance зі стратегією "Жадібна"
            CryptoBot bot1 = new CryptoBot(binance, greedyStrategy);
            Console.WriteLine("Binance з Жадібною стратегією:");
            bot1.MakeDecision();

            Console.WriteLine();

            // Coinbase зі стратегією "Середня ціна"
            CryptoBot bot2 = new CryptoBot(coinbase, averagePriceStrategy);
            Console.WriteLine("Coinbase зі Стратегією середньої ціни:");
            bot2.MakeDecision();
        }
    }
}