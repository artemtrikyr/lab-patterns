﻿using System;
namespace Paterns_arch_2
{
    public class CryptoBot
    {

        //реалізація торгового бота
        private readonly ICryptoExchange _exchange;
        private readonly ITradeStrategy _strategy;

        public CryptoBot(ICryptoExchange exchange, ITradeStrategy strategy)
        {
            _exchange = exchange;
            _strategy = strategy;
        }

        public void MakeDecision()
        {
            var priceHistory = _exchange.GetPriceHistory();
            var currentPrice = _exchange.GetCurrentPrice();

            var buyPrice = _strategy.GetBuyPrice(priceHistory);
            var sellPrice = _strategy.GetSellPrice(priceHistory);

            Console.WriteLine($"Поточна ціна: {currentPrice}");
            Console.WriteLine($"Ціна купівлі: {buyPrice}");
            Console.WriteLine($"Ціна продажу: {sellPrice}");

            if (currentPrice < buyPrice)
            {
                Console.WriteLine("Рішення: Купувати.");
            }
            else if (currentPrice > sellPrice)
            {
                Console.WriteLine("Рішення: Продавати.");
            }
            else
            {
                Console.WriteLine("Рішення: Тримати.");
            }
        }
    }
}

